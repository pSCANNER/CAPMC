USE [omopcrcdata]
GO

/****** Object:  Table [dbo].[phi_location]    Script Date: 11/14/2017 2:52:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[phi_location](
	[phi_location_id] [int] IDENTITY(10000,1) NOT NULL,
	[master_id] [varchar](100) NOT NULL,
	[use_concept_id] [int] NULL,
	[use_source_value] [varchar](50) NULL,
	[use_source_concept_id] [int] NULL,
	[type_concept_id] [int] NULL,
	[type_source_value] [varchar](50) NULL,
	[type_source_concept_id] [int] NULL,
	[value] [varchar](50) NULL,
	[address_line_1] [varchar](100) NULL,
	[address_line_2] [varchar](100) NULL,
	[city] [varchar](50) NULL,
	[district] [varchar](50) NULL,
	[state] [varchar](50) NULL,
	[postal_code] [varchar](50) NULL,
	[country] [varchar](50) NULL,
	[preferred_record] [int] NULL,
	[period_start_date] [datetime] NULL,
	[period_end_date] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


