USE [omopcrcdata]
GO

/****** Object:  Table [dbo].[phi_person]    Script Date: 11/14/2017 2:48:51 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[phi_person](
	[phi_person_id] [int] IDENTITY(10000,1) NOT NULL,
	[master_id] [varchar](100) NOT NULL,
	[active] [int] NULL,
	[cdm_id] [int] NOT NULL,
	[ssn] [varchar](50) NULL,
	[mrn] [varchar](50) NULL,
	[surname] [varchar](50) NULL,
	[first_name] [varchar](50) NULL,
	[title] [varchar](50) NULL,
	[middle_name] [varchar](50) NULL,
	[nickname] [varchar](50) NULL,
	[qualifications] [varchar](50) NULL,
	[honorifics] [varchar](50) NULL,
	[maiden_name] [varchar](50) NULL,
	[employer] [varchar](50) NULL,
	[employer_period_start_date] [datetime] NULL,
	[employer_period_end_date] [datetime] NULL,
	[gender_concept_id] [int] NULL,
	[gender_source_value] [varchar](100) NULL,
	[gender_source_concept_id] [int] NULL,
	[race_concept_id] [int] NOT NULL,
	[race_source_value] [varchar](100) NULL,
	[race_source_concept_id] [int] NULL,
	[ethnicity_concept_id] [int] NOT NULL,
	[ethnicity_source_value] [varchar](100) NULL,
	[ethnicity_source_concept_id] [int] NULL,
	[birth_date] [datetime] NULL,
	[birthplace] [varchar](50) NULL,
	[deceased] [varchar](50) NULL,
	[deceased_datetime] [datetime] NULL,
	[marital_status_concept_id] [int] NOT NULL,
	[marital_status_source_value] [varchar](100) NULL,
	[marital_status_source_concept_id] [int] NULL,
	[mothers_maiden_name] [varchar](50) NULL,
	[multiple_birth_boolean] [varchar](50) NULL,
	[multiple_birth_integer] [int] NULL,
	[photo] [text] NULL,
	[language_concept_id] [int] NULL,
	[language_source_value] [varchar](100) NULL,
	[language_source_concept_id] [int] NULL,
	[preferred_language_concept_id] [int] NULL,
	[preferred_language_source_value] [varchar](100) NULL,
	[preferred_language_source_concept_id] [int] NULL,
	[general_practitioner] [varchar](50) NULL,
	[managing_organization] [varchar](50) NULL,
	[source_system] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


