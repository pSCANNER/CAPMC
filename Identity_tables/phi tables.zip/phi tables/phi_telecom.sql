USE [omopcrcdata]
GO

/****** Object:  Table [dbo].[phi_telecom]    Script Date: 11/14/2017 2:53:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[phi_telecom](
	[phi_telecom_id] [int] IDENTITY(10000,1) NOT NULL,
	[master_id] [varchar](50) NOT NULL,
	[system_concept_id] [int] NULL,
	[system_source_value] [varchar](50) NULL,
	[system_source_concept_id] [int] NULL,
	[value] [varchar](50) NULL,
	[use_concept_id] [int] NULL,
	[use_source_value] [varchar](50) NULL,
	[use_source_concept_id] [int] NULL,
	[rank] [varchar](50) NULL,
	[preferred_record] [int] NULL,
	[telcom_start_date] [datetime] NULL,
	[telcom_end_date] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


